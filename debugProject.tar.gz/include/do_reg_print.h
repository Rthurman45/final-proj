#ifndef DO_REG_PRINT_H
#define DO_REG_PRINT_H

void do_reg_print(long int* reg_value);

#endif