#ifndef DO_BACK_PRINT_H
#define DO_BACK_PRINT_H

void do_back_print(void* P, const char* format, long int depth);

#endif