#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include "../include/do_back_print.h"

void do_back_print(void* P, const char* format, long int depth) {
    // create symbol info struct (contains data about the stack frame P is pointing to)
    Dl_info info;
    dladdr(P, &info);

    // cast symbol address to unsigned long instead of void*
    unsigned long address = (unsigned long)info.dli_saddr;

    // print function information in this format: <depth>, <symbol address>, <symbol name>, <file name>
    printf(format, depth, address, info.dli_sname, info.dli_fname);
}